---
layout: page
title: Showtimes
subtitle: 
---

## September 2016
September 2nd  
**Waupaca Rotary Oktoberfest**  
Waupaca, WI

September 23rd  
**Private Wedding**  
Appleton, WI

## October 2016
October 9th, 12-4  
**Stetsonville Community Center Public Dance**  
Stetsonville, WI

## November 2016
November 8th, 6-8  
**King Veteran’s Home Veteran’s Day celebration**  
Waupaca, WI

## December 2016
December 3rd, 12-3  
**Spencer Lake, Waupaca Taste of Christmas**  
Waupaca, WI

## January 2017
January 21st  
**Private Wedding**  
Milwaukee, WI

## February 2017
February 10th, 7-11  
**Waupaca Rotary Valentine’s party**  
Waupaca Rotary Valentine’s party with dancing, food and free-play Casino! Incredible way to enjoy Valentine’s!  
Waupaca, WI

## March 2017
March 11th, 1-5  
**Justmann Band 70th Anniversary**   
Public Dance & party celebrating the 70th Anniversary of the Justmann Band originally started by my Father, Andy, at the tender age of 16 in 1947!  
Mayville Park Pavillion, WI

## July 2017
July 1st  
**Private Wedding**  
Stevens Point, WI 